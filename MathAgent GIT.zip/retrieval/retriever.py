import os
from sentence_transformers import SentenceTransformer
from qdrant_client import QdrantClient
from qdrant_client.models import PointStruct
import requests
from bs4 import BeautifulSoup

# Load model
model = SentenceTransformer("all-MiniLM-L6-v2")

# Connect to Qdrant running in Docker
qdrant = QdrantClient(host="localhost", port=6333)
COLLECTION_NAME = "math_kb"

# DuckDuckGo scraping
def duckduckgo_search(query: str) -> str:
    try:
        headers = {"User-Agent": "Mozilla/5.0"}
        url = f"https://html.duckduckgo.com/html/?q={query}"
        response = requests.get(url, headers=headers)
        soup = BeautifulSoup(response.text, "html.parser")
        results = soup.find_all("a", {"class": "result__snippet"}, limit=1)
        return results[0].text if results else ""
    except:
        return ""

# Wikipedia summary
def get_wikipedia_summary(query: str) -> str:
    try:
        title = query.replace(" ", "_")
        url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{title}"
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            return data.get("extract", "")
        return ""
    except:
        return ""

# Web Fallback
def web_search(query: str) -> str:
    try:
        wiki_summary = get_wikipedia_summary(query)
        if wiki_summary:
            return f"🌐 From Wikipedia:\n\n{wiki_summary}"

        duck_result = duckduckgo_search(query)
        if duck_result:
            return f"🌐 From DuckDuckGo:\n\n{duck_result}"

        return " No relevant web information found."
    except Exception as e:
        return f" Web search failed: {e}"

# Knowledge Base Search
def search_kb(query: str, top_k: int = 1) -> str:
    try:
        query_vec = model.encode(query).tolist()
        results = qdrant.search(
            collection_name=COLLECTION_NAME,
            query_vector=query_vec,
            limit=top_k
        )
        if results and results[0].score > 0.75:
            return results[0].payload["solution"]
        return None
    except Exception as e:
        return f" KB search error: {e}"

# Master router
def get_solution(query: str) -> str:
    kb_answer = search_kb(query)
    if kb_answer:
        return f" From Knowledge Base:\n\n{kb_answer}"

    return web_search(query)