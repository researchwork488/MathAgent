import streamlit as st
import csv
from datetime import datetime

st.title("Feedback Logging Test")

question = st.text_input("Question asked:", value="What is the derivative of x^2?")
answer = "To find the derivative of x², use the power rule: d/dx(x^n) = n*x^(n-1). So d/dx(x^2) = 2x."

if st.button("Yes"):
    with open("feedback/feedback_log.csv", "a", newline='') as f:
        writer = csv.writer(f)
        writer.writerow([datetime.now(), question, answer, "positive", ""])
    st.success("Feedback recorded")

feedback_text = st.text_input("What went wrong?")
if st.button(" No"):
    with open("feedback/feedback_log.csv", "a", newline='') as f:
        writer = csv.writer(f)
        writer.writerow([datetime.now(), question, answer, "negative", feedback_text])
    st.success(" Feedback recorded")