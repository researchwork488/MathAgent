import streamlit as st
import csv
from datetime import datetime
import sys
import os

# Path to access retriever.py
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../retrieval')))
from retriever import get_solution

# UI setup
st.set_page_config(page_title="Math Agent", layout="centered")
st.title("📘 Math Agent – Your AI Math Professor")
st.markdown("Ask a math question to get a step-by-step solution!")

if "response" not in st.session_state:
    st.session_state.response = None
if "question" not in st.session_state:
    st.session_state.question = None

# Input box
query = st.text_input("✏️ Enter your math question:")

# Submit button
if st.button("Get Solution"):
    if query.strip():
        st.session_state.question = query
        st.session_state.response = get_solution(query)

# Show result if available
if st.session_state.response:
    st.markdown("### Answer:")
    st.write(st.session_state.response)

    # Feedback
    st.markdown("### Was this helpful?")
    
    col1, col2 = st.columns(2)

    with col1:
        if st.button("👍 Yes"):
            with open("feedback/feedback_log.csv", "a", newline='') as f:
                writer = csv.writer(f)
                writer.writerow([datetime.now(), st.session_state.question, st.session_state.response, "positive", ""])
            st.success(" Thanks for your feedback!")

    with col2:
        feedback_text = st.text_input("If not, what was wrong?", key="feedback_text")
        if st.button("👎 No"):
            with open("feedback/feedback_log.csv", "a", newline='') as f:
                writer = csv.writer(f)
                writer.writerow([datetime.now(), st.session_state.question, st.session_state.response, "negative", feedback_text])
            st.info(" Feedback recorded. Thank you!")