import pandas as pd
from sentence_transformers import SentenceTransformer
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct

# Configuration
COLLECTION_NAME = "math_kb"
CSV_FILE = "data/math_questions.csv"

# Connect to Docker Qdrant Server
qdrant = QdrantClient(host="localhost", port=6333)

# Load model
model = SentenceTransformer("all-MiniLM-L6-v2")

# Load dataset
df = pd.read_csv(CSV_FILE)

# Drop rows with missing data
df = df.dropna(subset=["question", "solution"])

# Recreate collection
qdrant.recreate_collection(
    collection_name=COLLECTION_NAME,
    vectors_config=VectorParams(size=384, distance=Distance.COSINE),
)

# Prepare data
points = []
for idx, row in df.iterrows():
    question = row["question"]
    solution = row["solution"]
    embedding = model.encode(question).tolist()
    points.append(PointStruct(id=idx, vector=embedding, payload={"question": question, "solution": solution}))

# Upload points to Qdrant
qdrant.upsert(collection_name=COLLECTION_NAME, points=points)

print(f" Ingested {len(points)} math questions into Qdrant.")